; (function ($) {
    "use strict"


})(jQuery)